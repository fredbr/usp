public class Quadrado extends Retangulo {
    public Quadrado(boolean filled, String cor, double x) {
        super(filled, cor, x, x);
    }
}
