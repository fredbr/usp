public class Pessoa {
    public int compareTo(Pessoa rhs) {
        return 0;
    }
}
